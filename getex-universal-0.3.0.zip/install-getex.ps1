$dest = Join-Path $env:LOCALAPPDATA 'MP\bin'
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item "$PSScriptRoot\getex.js" $dest -Force
Copy-Item "$PSScriptRoot\getex.cmd" $dest -Force
$userPath = [Environment]::GetEnvironmentVariable('Path','User')
$parts = ($userPath -split ';')
if ($parts -notcontains $dest) { [Environment]::SetEnvironmentVariable('Path', ($userPath.TrimEnd(';') + ';' + $dest).TrimStart(';'),'User') }
Write-Host 'Installed getex. Open a NEW terminal, then run: getex MPxiom'
