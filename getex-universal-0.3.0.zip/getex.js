#!/usr/bin/env node
'use strict';
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const https=require('node:https');
const {spawnSync}=require('node:child_process');
const DEFAULT_OWNER=process.env.GETEX_OWNER||'mmangaming999';
const NAME=/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/;
function parseTarget(input){
 let value=input.trim();
 if(value.startsWith('https://github.com/')){
   let u=new URL(value); if(u.host!=='github.com'||u.search||u.hash)throw Error('Use a GitHub repository URL without query parameters');
   value=u.pathname.replace(/^\/+|\/+$/g,'').replace(/\.git$/,'');
 }
 const parts=value.split('/');
 if(parts.length===1)parts.unshift(DEFAULT_OWNER);
 if(parts.length!==2||!parts.every(p=>NAME.test(p)))throw Error('Package must be NAME, owner/repo, or https://github.com/owner/repo');
 return {owner:parts[0],repo:parts[1]};
}
function request(url,asJson=false,depth=0){return new Promise((resolve,reject)=>{
 if(depth>5)return reject(Error('Too many redirects'));
 const u=new URL(url);
 if(u.protocol!=='https:'||!['api.github.com','raw.githubusercontent.com','codeload.github.com'].includes(u.hostname))return reject(Error('Unsupported download host'));
 const req=https.get(url,{headers:{'User-Agent':'MP-getex-universal-0.3.0','Accept':'application/vnd.github+json'},timeout:30000},res=>{
   if([301,302,307,308].includes(res.statusCode)&&res.headers.location){res.resume();request(new URL(res.headers.location,url).href,asJson,depth+1).then(resolve,reject);return;}
   if(res.statusCode!==200){const code=res.statusCode;res.resume();return reject(Error('HTTP '+code+' for '+url));}
   let pieces=[],bytes=0;
   res.on('data',data=>{bytes+=data.length;if(bytes>12*1024*1024){res.destroy(Error('Download too large'));return;}pieces.push(data);});
   res.on('end',()=>{const b=Buffer.concat(pieces);if(!asJson)return resolve(b);try{resolve(JSON.parse(b.toString('utf8')));}catch(e){reject(Error('Invalid JSON from GitHub'));}});
 });req.on('error',reject);req.on('timeout',()=>req.destroy(Error('Request timeout')));
});}
const api=(suffix)=>request('https://api.github.com/'+suffix,true);
const encoded=(s)=>encodeURIComponent(s);
async function getRef(owner,repo,ref){if(ref)return ref;
 try{const release=await api(`repos/${owner}/${repo}/releases/latest`);if(release.tag_name)return release.tag_name;}catch(e){if(!e.message.includes('HTTP 404'))throw e;}
 const info=await api(`repos/${owner}/${repo}`);return info.default_branch||'main';}
function safeFile(f){return typeof f==='string'&&!f.includes('\\')&&!f.includes('\0')&&!f.startsWith('/')&&!f.split('/').some(p=>p===''||p==='.'||p==='..')&&f.length<256;}
async function install(target,options={}){
 const {owner,repo}=parseTarget(target);
 const ref=await getRef(owner,repo,options.ref);
 console.log(`Discovering ${owner}/${repo} (${ref})...`);
 const tree=await api(`repos/${owner}/${repo}/git/trees/${encoded(ref)}?recursive=1`);
 if(tree.truncated)throw Error('Repository tree is too large');
 const files=tree.tree.filter(x=>x.type==='blob').map(x=>x.path);
 if(files.length>150)throw Error('Too many files (limit 150)');
 if(!files.every(safeFile))throw Error('Unsafe filename in repository');
 if(!files.includes('package.json')||!files.includes('main.mp'))throw Error('Extension needs package.json and main.mp at its root');
 const base=`https://raw.githubusercontent.com/${encoded(owner)}/${encoded(repo)}/${encoded(ref)}/`;
 const manifest=JSON.parse((await request(base+'package.json')).toString('utf8'));
 if(manifest.language!=='MP'||manifest.entry!=='main.mp')throw Error('Expected MP package.json with language="MP" and entry="main.mp"');
 const name=manifest.name;
 if(!NAME.test(name))throw Error('Invalid package name in manifest');
 if(name.toLowerCase()!==repo.toLowerCase())throw Error('Package name must match repository name');
 if(!/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(manifest.version))throw Error('Invalid version in manifest');
 const destRoot=path.join(os.homedir(),'.mp','packages');fs.mkdirSync(destRoot,{recursive:true});
 const dest=path.join(destRoot,repo),temp=path.join(destRoot,'.getex-'+process.pid+'-'+repo);
 fs.rmSync(temp,{recursive:true,force:true});fs.mkdirSync(temp,{recursive:true});
 try{
  let total=0;
  for(const file of files){
   if(file.startsWith('.git/')||file==='node_modules'||file.startsWith('node_modules/'))continue;
   const bytes=await request(base+file.split('/').map(encoded).join('/'));total+=bytes.length;
   if(total>24*1024*1024)throw Error('Package exceeds 24 MiB');
   const out=path.join(temp,...file.split('/'));fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,bytes);
  }
  if(!fs.readFileSync(path.join(temp,'main.mp'),'utf8').trim())throw Error('Empty main.mp');
  if(manifest.dependencies&&Object.keys(manifest.dependencies).length){
   console.log('Installing npm dependencies (package install scripts may run). Only install trusted repositories.');
   const cmd=process.platform==='win32'?'npm.cmd':'npm';
   const result=spawnSync(cmd,['install','--omit=dev','--no-audit','--no-fund'],{cwd:temp,stdio:'inherit',timeout:300000,shell:process.platform==='win32'});
   if(result.error||result.status!==0)throw Error('npm install failed');
  }
  // Only replace installed version after the full download and dependency installation succeeds.
  const backup=dest+'.getex-backup';fs.rmSync(backup,{recursive:true,force:true});
  if(fs.existsSync(dest))fs.renameSync(dest,backup);
  try{fs.renameSync(temp,dest);fs.rmSync(backup,{recursive:true,force:true});}
  catch(e){if(fs.existsSync(backup))fs.renameSync(backup,dest);throw e;}
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
 console.log(`Installed ${repo} v${manifest.version} from ${owner}/${repo} (${ref})`);
 console.log(`Use in MP: add "${repo}"`);
}
function help(){console.log(`Universal getex for MP (0.3.0)\n\nUsage:\n  getex MPG\n  getex owner/repository\n  getex https://github.com/owner/repository\n  getex owner/repository --ref v1.2.3\n\nShort names use ${DEFAULT_OWNER} by default (override with GETEX_OWNER).\nUses the latest GitHub release; otherwise uses the repository's default branch.\nPackages must have package.json and main.mp. Dependencies run npm install with --ignore-scripts.`);}
if(require.main===module){const args=process.argv.slice(2);if(!args.length||['-h','--help'].includes(args[0])){help();process.exit(args.length?0:1);}let ref;const i=args.indexOf('--ref');if(i!==-1){ref=args[i+1];if(!ref||!NAME.test(ref))throw Error('Invalid --ref');args.splice(i,2);}if(args.length!==1){help();process.exit(1);}install(args[0],{ref}).catch(e=>{console.error('getex:',e.message);process.exitCode=1;});}
module.exports={parseTarget,install};
