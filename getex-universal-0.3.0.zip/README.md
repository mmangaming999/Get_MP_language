# Universal getex 0.3.0

Install once on Windows using `powershell -ExecutionPolicy Bypass -File .\install-getex.ps1` inside the extracted folder. Restart Terminal afterward.

Install packages from **any GitHub repository** that follows MP packaging conventions:

```powershell
getex MPG
getex MPxiom
getex otherUser/OtherExtension
getex https://github.com/otherUser/OtherExtension
getex otherUser/OtherExtension --ref v1.0.0
```

Short names use `mmangaming999` as the default GitHub owner (or `$env:GETEX_OWNER` if configured). getex checks the **latest GitHub release** and otherwise the repository default branch. A repository must include `package.json` with `name`, `version`, `language: "MP"`, and `entry: "main.mp"`, plus `main.mp` in its root. All repository files (within size/quantity limits) are installed, including JavaScript components for graphical extensions like MPG.

Dependencies are installed using `npm install`, including any package lifecycle scripts needed by Electron. **Those scripts can execute code on your computer**, so only install repositories you trust. GitHub packages contain executable code: inspect the repository before installing. Universal getex is for installation, not automatic compiler compatibility; some packages still need an MP compiler/runtime update.

Requires Node.js, npm and internet. This version is packaged and locally syntax-tested, but GitHub network install and Windows Electron launch were not tested here.
