@echo off
node "%~dp0getex.js" %*
